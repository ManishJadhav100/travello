from django.contrib import admin
from .models import Destination
from .models import News_post
# Register your models here.

admin.site.register(Destination)
admin.site.register(News_post)

